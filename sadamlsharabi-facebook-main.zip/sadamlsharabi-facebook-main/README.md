# اوامر تثبيت الاداة

git clone https://github.com/sadamshr3be/sadamlsharabi-facebook

cd sadamlsharabi-facebook

امر التشغيل


python2 lovehacker.py


شرحها علـّۓ. اليوتيوب

https://youtu.be/l6bTJTBOT_g
جميع قنواتي

TErmux
حسابي علـّۓ. اليوتيوب
https://www.youtube.com/channel/UC6KWVWMUn210EJYDyUHQhKQ
حسابي https://github.com/sadamshr3be
حسابي @sadam_alsharabi
الجروب @alsharabii ,   
الموقع http://sadam-alsharabi.roo7.biz
https://t.me/termuxalsharabi
